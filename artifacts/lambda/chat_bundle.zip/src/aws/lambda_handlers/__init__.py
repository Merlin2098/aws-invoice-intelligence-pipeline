"""Lambda control-plane entrypoints."""

